# GraphQL API Specification Template

## Table of Contents

1. [Common Components](#common-components)
2. [Lint Schema](#lint-schema)
3. [Imports File](#imports-graphql)
4. [Publish Schema](#publish-schema)

---

## Common Components
### Common Components Specification
CommonComponentsSpecification directory will contain the git submodules of other schema type and directive definitions that the schema is dependent on

#### Cloning the Repository with Submodules:
If you are cloning this repository and it includes submodules, use the following command to clone the repository and all of its submodules at once:
```
git clone --recursive <repository-url>
git submodule update --init --recursive
```
#### Existing Repository

To include common components in your exisitng repo, add the necessary submodule by running:

```
git submodule add  git@github.paypal.com:ApiSpecifications-R/CommonComponentsSpecification.git CommonComponentsSpecification
git submodule update --init --recursive
```
 **Note**:  
> If you encounter the following error after running the first command:  
> `'CommonComponentSpecification' did not match any files'`,  
> then run the following command to resolve the issue:
> 
> ```
> git rm --cached CommonComponentsSpecification
> 

#### Branch Naming Convention
Specification changes for the schema should be implemented in branches following the naming convention `v<version-number>`, for example, `v1.0`. This convention helps in organizing and tracking changes according to the version they belong to.

## Lint Schema

Ensure your GraphQL schema follows best practices and standards by running the linting script.

```bash
npm install
npm run lint
```

### Configuration for Linting
For integrating linting in an existing repo or running it with common components (whether v4 or v5), please follow the respective guides linked below for detailed instructions. By default, the template is configured with .eslintrc.json for v5 common components.

- [Running Linting with v5 common components](./Config_V5_Linting.md)
- [Running Linting with v4 common components](./Config_V4_Linting.md)
- [Running Linting in Existing Repository](./Existing_Repo_Linting.md)

For more detailed information on linting guidelines and configuration, please refer to the [linting](https://github.paypal.com/GraphQL-R/graphql-fanny-pack/blob/master/packages/eslint-plugin-graphql/README.md) guidelines documentation.

Note: Linting won't function on the template repository. After creating valid schema files with content, run linting for validation.

## Managing Common Components with `imports.graphql`

In our project, we maintain a special file called `imports.graphql` to manage imports for common components. This file helps streamline the import process for commonly used components across different parts of the project, aiding in bundling only the imported or used common files. This approach ensures that only the necessary common components are included when publishing or packaging the project.

#### Example `imports.graphql` File
```graphql
#import securityClassification from '../CommonComponentsSpecification/v5/schema/graphql/directives/securityClassification.graphql'
#import authPolicy from '../CommonComponentsSpecification/v5/schema/graphql/directives/authPolicy.graphql'
#import pattern from '../CommonComponentsSpecification/v5/schema/graphql/directives/pattern.graphql'
#import stringLength from '../CommonComponentsSpecification/v5/schema/graphql/directives/stringLength.graphql'
#import listLength from '../CommonComponentsSpecification/v5/schema/graphql/directives/listLength.graphql'
```

## Publish Schema
For guidance on publishing schema, refer to [This Readme](./docs/PUBLISH_README.md)