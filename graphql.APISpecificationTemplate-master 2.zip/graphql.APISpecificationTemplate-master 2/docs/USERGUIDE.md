# GraphQL Example Usage

### Enums
The repository provides Enums to define specific value sets for fields. For example:

```graphql
enum PaymentStatus {
  IN_STOCK
  LOW_STOCK
  OUT_OF_STOCK
}
```
**File Location**: `src/graphql/enums/AvailabilityFilter.graphql`


This AvailabilityFilter enum is used to filter the products by availability status.

### Inputs
Inputs are used to structure mutation arguments. Here's an example:
```graphql
input CreateProductInput {
  name: String!
  description: String
  quantity: Int!
  category: Product_Category!
}
```
**File Location**: `schema/input/CreateProductInput.graphql`


This input is utilized in the createProduct mutation to define the product details.



### Scalars
```graphql
type Product {
  id: ID!
  name: String!
  description: String
  quantity: Int!
  category: Product_Category!
}
```
**File Location**: `schema/types/Product.graphql`


### Queries
The repository includes the following five example queries for data retrieval:

- **products**: Retrieves a list of all products available, including id, name, description, quantity, and category.
- **product**: Retrieves details of a specific product by id.
- **productCountByCategory**: Retrieves the count of products by each category.
- **productsByAvailability**: Retrieves products based on their availability, with options for filtering and sorting.

#### Example query:
```graphql
query {
  products(first: 10) {
    edges {
      node {
        id
        name
        quantity
        category
      }
    }
    pageInfo {
      hasNextPage
      endCursor
    }
  }
}
```
**File Location**: `schema/Query.graphql`
### Mutations
The repository includes three example mutations for data manipulation:
- **createProduct**: Adds a new product
- **updateProductQuantity**: Updates the available quantity of a product
- **addDescription**: Adds a description to a product

#### Example Mutation
```graphql
mutation {
  createProduct(input: {
    name: "New Product"
    description: "A brand new product"
    quantity: 10
    category: ELECTRONICS
  }) {
    id
    name
    description
    quantity
  }
}
```
**File Location**: `schema/Mutation.graphql`

For more detailed information on the GraphQL standards followed in this repository, including best practices for schema design, mutation patterns, and query structures, please refer to the [GraphQL Schema Standards](https://github.paypal.com/PayPal-R/technical-decisions/blob/528863b2efebdb781f569d8c5787adf68d418697/adr/api-platform/graphql/schema-standards.md)